/*
 * File:           C:\Users\oleg.tetushkin\Documents\ADAU1701RasPi_combo V2\adau1701_192\ADAU1701_192_IC_1_PARAM.h
 *
 * Created:        Tuesday, April 5, 2022 3:29:34 PM
 * Description:    ADAU1701_192:IC 1 parameter RAM definitions.
 *
 * This software is distributed in the hope that it will be useful,
 * but is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR
 * CONDITIONS OF ANY KIND, without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 *
 * This software may only be used to program products purchased from
 * Analog Devices for incorporation by you into audio products that
 * are intended for resale to audio product end users. This software
 * may not be distributed whole or in any part to third parties.
 *
 * Copyright ©2022 Analog Devices, Inc. All rights reserved.
 */
#ifndef __ADAU1701_192_IC_1_PARAM_H__
#define __ADAU1701_192_IC_1_PARAM_H__


/* Module SW vol 1 - Single SW slew vol (adjustable)*/
#define MOD_SWVOL1_COUNT                               2
#define MOD_SWVOL1_DEVICE                              "IC1"
#define MOD_SWVOL1_ALG0_TARGET_ADDR                    0
#define MOD_SWVOL1_ALG0_TARGET_FIXPT                   0x00016FA9
#define MOD_SWVOL1_ALG0_TARGET_VALUE                   SIGMASTUDIOTYPE_FIXPOINT_CONVERT(0.0112201845430196)
#define MOD_SWVOL1_ALG0_TARGET_TYPE                    SIGMASTUDIOTYPE_FIXPOINT
#define MOD_SWVOL1_ALG0_STEP_ADDR                      1
#define MOD_SWVOL1_ALG0_STEP_FIXPT                     0x00000800
#define MOD_SWVOL1_ALG0_STEP_VALUE                     SIGMASTUDIOTYPE_FIXPOINT_CONVERT(0.000244140625)
#define MOD_SWVOL1_ALG0_STEP_TYPE                      SIGMASTUDIOTYPE_FIXPOINT

/* Module balance_R - Single SW slew vol (adjustable)*/
#define MOD_BALANCE_R_COUNT                            2
#define MOD_BALANCE_R_DEVICE                           "IC1"
#define MOD_BALANCE_R_ALG0_TARGET_ADDR                 2
#define MOD_BALANCE_R_ALG0_TARGET_FIXPT                0x0050C335
#define MOD_BALANCE_R_ALG0_TARGET_VALUE                SIGMASTUDIOTYPE_FIXPOINT_CONVERT(0.630957344480193)
#define MOD_BALANCE_R_ALG0_TARGET_TYPE                 SIGMASTUDIOTYPE_FIXPOINT
#define MOD_BALANCE_R_ALG0_STEP_ADDR                   3
#define MOD_BALANCE_R_ALG0_STEP_FIXPT                  0x00000800
#define MOD_BALANCE_R_ALG0_STEP_VALUE                  SIGMASTUDIOTYPE_FIXPOINT_CONVERT(0.000244140625)
#define MOD_BALANCE_R_ALG0_STEP_TYPE                   SIGMASTUDIOTYPE_FIXPOINT

/* Module balance_L - Single SW slew vol (adjustable)*/
#define MOD_BALANCE_L_COUNT                            2
#define MOD_BALANCE_L_DEVICE                           "IC1"
#define MOD_BALANCE_L_ALG0_TARGET_ADDR                 4
#define MOD_BALANCE_L_ALG0_TARGET_FIXPT                0x0050C335
#define MOD_BALANCE_L_ALG0_TARGET_VALUE                SIGMASTUDIOTYPE_FIXPOINT_CONVERT(0.630957344480193)
#define MOD_BALANCE_L_ALG0_TARGET_TYPE                 SIGMASTUDIOTYPE_FIXPOINT
#define MOD_BALANCE_L_ALG0_STEP_ADDR                   5
#define MOD_BALANCE_L_ALG0_STEP_FIXPT                  0x00000800
#define MOD_BALANCE_L_ALG0_STEP_VALUE                  SIGMASTUDIOTYPE_FIXPOINT_CONVERT(0.000244140625)
#define MOD_BALANCE_L_ALG0_STEP_TYPE                   SIGMASTUDIOTYPE_FIXPOINT

/* Module Inv1 - Signal Invert*/
#define MOD_INV1_COUNT                                 1
#define MOD_INV1_DEVICE                                "IC1"
#define MOD_INV1_EQ1940INVERT1GAIN_ADDR                6
#define MOD_INV1_EQ1940INVERT1GAIN_FIXPT               0xFF800000
#define MOD_INV1_EQ1940INVERT1GAIN_VALUE               SIGMASTUDIOTYPE_FIXPOINT_CONVERT(-1)
#define MOD_INV1_EQ1940INVERT1GAIN_TYPE                SIGMASTUDIOTYPE_FIXPOINT

/* Module Inv1_2 - Signal Invert*/
#define MOD_INV1_2_COUNT                               1
#define MOD_INV1_2_DEVICE                              "IC1"
#define MOD_INV1_2_EQ1940INVERT2GAIN_ADDR              7
#define MOD_INV1_2_EQ1940INVERT2GAIN_FIXPT             0xFF800000
#define MOD_INV1_2_EQ1940INVERT2GAIN_VALUE             SIGMASTUDIOTYPE_FIXPOINT_CONVERT(-1)
#define MOD_INV1_2_EQ1940INVERT2GAIN_TYPE              SIGMASTUDIOTYPE_FIXPOINT

#endif
